#pragma once
#include "std_lib_facilities.h"
#include "utilities.h"

void testCallByValue();
void testCallByReference();
void testVectorSorting();
void teststruct();
void testString();