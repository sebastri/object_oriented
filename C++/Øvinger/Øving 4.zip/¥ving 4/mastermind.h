#pragma once
#include "tests.h"
#include "utilities.h"

int checkCharactersAndPosition(string code, string guess);
int checkCharacters(string code, string guess);
void playMastermind();
