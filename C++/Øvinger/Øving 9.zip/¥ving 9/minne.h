#pragma once
#include <iostream>
using namespace std;


void fillInFibonacciNumbers(int result[], int length);
void printArray(int arr[], int length);
void createFibonacci();
