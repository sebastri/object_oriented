#include "Card.h"
#include "CardDeck.h"
#include "BlackJack.h"
#include "std_lib_facilities.h"

//trekke to kort drawcard()

void BlackJack::question(){
    string x = "";
    cout << "Vil du trekke et kort, eller stå? (j/s)";
    cin >> x;
    if (x == "j"){
        drawPlayer();
        cout << "Din verdi er nå: " << valuePlayer(handPlayer);
    }
    else if(x == "s"){
        cout << "Din verdi er fortsatt: " << valuePlayer(handPlayer);
    }

}



void BlackJack::firstRound(){
    
    Card c2 = cards.drawCard();
    handPlayer.push_back(c2);

    Card c = cards.drawCard();
    handDealer.push_back(c);

    handPlayer.push_back(cards.drawCard());
    handDealer.push_back(cards.drawCard());
    
}

void BlackJack::drawPlayer(){
    handPlayer.push_back(cards.drawCard());
}

void BlackJack::drawDealer(){
    if (valueDealer(handDealer))
    handDealer.push_back(cards.drawCard());
}


int rankToInt(Rank invalue){
    int value = rankValue.at(invalue);
    return value;
}

void BlackJack::initialGame(){
    handPlayer.clear();
    handDealer.clear();
}


int BlackJack::valuePlayer(vector<Card> vec){
    int value = 0;
    for (auto i:vec){
        Rank r = i.getRank();
        value += rankToInt(r);
    }
    cout << value << endl;
    return value;
}
    
int BlackJack::valueDealer(vector<Card> vec){
    int valueDealer = 0;
    for (auto i:vec){
        Rank r = i.getRank();
        valueDealer += rankToInt(r);
    }
    cout << valueDealer << endl;
    return valueDealer;
}

void BlackJack::printHand(vector<Card> vec){
    for (auto i:vec){
        cout << i.toString() << endl;
    }
}

void BlackJack::playGame(){
    
    cards.shuffle();
    firstRound();
    cout << "Dealers hånd: " << endl;
    printHand(handDealer);
    valueDealer(handDealer);
    cout << "Din hånd: " << endl;
    printHand(handPlayer);
    valuePlayer(handPlayer);

    int i = -1;

    while (i != 0){
    
    question();

    if (valuePlayer(handPlayer) > 21 && valueDealer(handDealer) <= 21){
        cout << "Du tapte!" << endl;
    }
    else if 


    }

    
}


//over 21 - ute av spillet

//dealer må stå på 17 eller større

//vinne

//1 ekte blackjack
//2 høyere sum enn dealer
//3 dealer høyere enn 21, samtidig som du har mindre enn 21