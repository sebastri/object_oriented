#pragma once
#include <vector>
#include <string>
#include <ctime>
#include <cstdlib>
#include <iostream>




void testTemplate();