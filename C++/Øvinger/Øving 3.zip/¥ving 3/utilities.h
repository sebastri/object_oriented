#pragma once
#include "std_lib_facilities.h"
#include "cannonball.h"

int randomWithLimits(int downlimit, int upperlimit);

void playTargetPractise();

