#pragma once
#include "std_lib_facilities.h"


void readToFile();
void readIn();

void countCharFile();
